import dateFormat from "dateformat";
import { Status, type Order, type OrderId } from "./models.js";

export class OrderManager {
  private orders: Order[] = [];

  addOrder(order: Order) {
    this.orders.push(order);
    const now = dateFormat(new Date(), "yyyy-MM-dd HH:mm:ss");
    console.log(`Order created at ${now}`);
  }

  serveOrder(id: OrderId) {
    const order = this.orders.find((o) => o.id === id);
    if (order) {
      order.status = Status.Served;
      const now = dateFormat(new Date(), "yyyy-MM-dd HH:mm:ss");
      console.log(`Order served at ${now}`);
    }
  }

  printOrders() {
    const printed = this.orders
      .map(
        (order) =>
          `Order ${order.id} (${order.status})\n\t${order.items
            .map((item) => `${item.name} (${item.type}): ${item.price}$`)
            .join("\n\t")}`
      )
      .join("\n\n");
    console.log(`ORDERS: \n\n${printed}\n`);
  }
}
