export type OrderId = number;
type OrderStatus = "Pending" | "Served" | "Cancelled";

type ItemType = "Food" | "Drink";

interface Item {
  name: string;
  type: ItemType;
  price: number;
}

export interface Order {
  id: OrderId;
  items: Item[];
  status: Status;
}

export enum Status {
  Pending = "Pending",
  Served = "served",
  Cancelled = "Cancelled",
}
