import { Status, type Order } from "./models.js";
import { OrderManager } from "./orderManager.js";

const orderManager = new OrderManager();

const order: Order = {
  id: 123,
  items: [
    { name: "pollo", price: 3, type: "Food" },
    { name: "coca", price: 3, type: "Drink" },
  ],
  status: Status.Pending,
};

orderManager.printOrders();

orderManager.addOrder(order);
orderManager.printOrders();

orderManager.serveOrder(123)
orderManager.printOrders();



// type SpecialItem = Item & { specialInstructions?: string };

// type AnyItem = Item | SpecialItem;
