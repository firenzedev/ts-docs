import { readFileSync } from "fs";
import type { MenuItem, Order } from "./models.js";
export class Storage {
  static readOrders(): Order[] {
    try {
      const json = readFileSync("orders.json");
      const input = JSON.parse(json.toString()) as unknown[];
      const orders: Order[] = [];
      for (const toBeValidated of input) {
        try {
          assertIsOrder(toBeValidated);
          assertHasItems(toBeValidated)
        //   toBeValidated.items[0].type
          orders.push(toBeValidated);
        } catch (error) {
          //skip, do nothing
          console.error("Not a proper order", toBeValidated)
        }
      }
      return orders;
    } catch (error) {
      return [];
    }
  }
}

function assertIsOrder(value: unknown): asserts value is Order {
  if (
    typeof value !== "object" ||
    value === null ||
    !("id" in value) ||
    !("items" in value) ||
    !("status" in value) ||
    !("tableId" in value)
  ) {
    throw new Error("Not a valid Order");
  }
}

function assertHasItems(
  order: Order
): asserts order is Order & { items: [MenuItem, ...MenuItem[]] } {
  if (order.items.length === 0) {
    throw new Error("Order must have at least one item");
  }
}
