import dateFormat from "dateformat";
import { Status, type Order, type OrderId } from "./models.js";
import { Printer } from "./Printer.js";
import { EventManager } from "./eventManager.js";
import { OrderNotFound, type Result } from "./errors/orderErrors.js";

export class OrderManager {
  private orders: Order[] = [];

  constructor(orders: Order[]) {
    this.orders = orders;
  }

  getOrder(orderId: OrderId): Result<Order, OrderNotFound> {
    const found = this.orders.find((order) => order.id === orderId);
    if (!found) {
      return {
        success: false,
        error: new OrderNotFound(orderId),
      };
    }
    return {
      success: true,
      data: found,
    };
  }

  cancelOrder(orderId: OrderId): Result<Order, OrderNotFound> {
    const found = this.getOrder(orderId);
    if (found.success) {
      found.data.status = Status.Cancelled;
    }
    return found;
  }
  private eventManager = new EventManager();

  addOrder(order: Order) {
    this.orders.push(order);
    this.eventManager.emit(EventManager.orderCreated(order.id));
  }

  serveOrder(id: OrderId): Result<undefined, OrderNotFound> {
    const order = this.orders.find((o: Order) => o.id === id);
    if (order) {
      order.status = Status.Served;
      this.eventManager.emit(EventManager.orderServed(order.id));
      return {
        success: true,
        data: undefined,
      };
    }
    return {
      success: false,
      error: new OrderNotFound(id),
    };
  }

  printOrders() {
    const printed = this.orders
      .map((order) => new Printer(order).print())
      .join("\n\n--------------\n");
    console.log(`ORDERS: \n\n${printed}\n`);
  }
}
