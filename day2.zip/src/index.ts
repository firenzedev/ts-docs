import type { Ok } from "./errors/orderErrors.js";
import { Menu } from "./Menu.js";
import { Status, type FoodItem, type MenuItem, type Order } from "./models.js";
import { OrderManager } from "./orderManager.js";
import { Storage } from "./storage.js";
import { createOrderId, createTableId } from "./utils.js";

Menu.print();

const selection = Menu.get().pizzaMargherita;

const selected = Menu.select("pizzaMargherita");
console.log("selected item", selected);

console.log(Menu.describeItem(selection));

const orders = Storage.readOrders();
const orderManager = new OrderManager(orders);

const id = 123;

const table1Order: Order = {
  id: createOrderId(id),
  items: [
    { name: "pollo", price: 3, type: "Food" },
    { name: "coca", price: 3, type: "Drink" },
  ],
  status: Status.Pending,
  tableId : createTableId(id)
};

const table2Order: Order = {
  id: createOrderId(456),
  tableId: createTableId(id),
  items: [
    { name: "Carbonara", price: 12.5, type: "Food", calories: 950 },
    {
      name: "Vino biano",
      price: 7,
      type: "Drink",
      alcoholic: true,
      specialInstructions: "Service freddo",
    },
  ],
  status: Status.Pending,
};

// orderManager.printOrders();

orderManager.addOrder(table1Order);
orderManager.addOrder(table2Order);
// orderManager.printOrders();

orderManager.serveOrder(createOrderId(123));
// orderManager.printOrders();

orderManager.cancelOrder(createOrderId(456));
// orderManager.printOrders();

// const result = orderManager.cancelOrder(createOrderId(4565));
// if (result.success) {
//   //do something
// } else {
//   //do something else
// }

// const order456 = orderManager.getOrder(createOrderId(456));
// const name = (order456 as Ok).data.items[0]!.name;
// const calories = (
//   (order456 as Ok).data.items[0]! as FoodItem
// ).calories!.toFixed(2);
// console.log(`${name} has ${calories} cal`);
