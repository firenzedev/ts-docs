import type { Order, OrderId } from "../models.js";

export class OrderNotFound extends Error {
  constructor(public orderId: OrderId) {
    super(`Order ${orderId} not found`);
    this.name = "OrderNotFoundError";
  }
}

export type Ok<T> = { success: true; data: T };

export type Ko<E> = { success: false; error: E };

export type Result<T, E = Error> = Ok<T> | Ko<Error>;
