import type { OrderId, TableId } from "./models.js";

interface Priceable {
  price: number;
}

export function applyDiscount(item: Priceable, discount: number) {
  return item.price * (1 - discount);
}

export function createOrderId(id: number): OrderId {
  return id as OrderId;
}


export function createTableId(id: number): TableId {
  return id as TableId;
}