import logger from "logger";
import type { OrderId } from "./models.js";

const log = logger.createLogger("event.log");

interface OrderCreatedEvent {
  type: "OrderCreated";
  orderId: OrderId;
  timestamp: Date;
}

interface OrderServedEvent {
  type: "OrderServed";
  orderId: OrderId;
  serverName: string;
  timestamp: Date;
}

interface OrderCancelledEvent {
  type: "OrderCancelled";
  orderId: OrderId;
  reason: string;
  timestamp: Date;
}

type OrderEvent = OrderCreatedEvent | OrderServedEvent | OrderCancelledEvent;

export class EventManager {
  static orderCreated(orderId: OrderId): OrderCreatedEvent {
    return {
      orderId,
      type: "OrderCreated",
      timestamp: new Date(),
    };
  }

  static orderServed(orderId: OrderId): OrderServedEvent {
    return {
      orderId,
      timestamp: new Date(),
      type: "OrderServed",
      serverName: "system",
    };
  }

  emit(event: OrderEvent) {
    switch (event.type) {
      case "OrderCreated":
        log.info(`Order ${event.orderId} created at ${event.timestamp}`);
        break;
      case "OrderServed":
        log.info(`Order ${event.orderId} served by ${event.serverName}`);
        break;
      case "OrderCancelled":
        log.info(`Order ${event.orderId} cancelled: ${event.reason}`);
        break;
      default:
        // Exhaustive check
        const _exhaustive: never = event;
        throw new Error(`Unhandled event type: ${_exhaustive}`);
    }
  }
}
