const MENU = {
  pizzaMargherita: { name: "Pizza Margherita", price: 8, type: "Food" },
  pizzaQuattroStagioni: { name: "Pizza 4 Stagioni", price: 10, type: "Food" },
  water: { name: "Water", price: 2, type: "Drink" },
  wine: { name: "Wine", price: 5, type: "Drink" },
} as const;


type MenuKeys = keyof typeof MENU;
type MenuItemValue = typeof MENU[MenuKeys];

export class Menu {
  static print() {
    // MENU.pizzaMargherita.name = "pippo";  X
    Object.entries(MENU).forEach(([key, item]) => {
      console.log(`${item.name} - $${item.price} (${item.type})`);
    });
  }

  static get() {
    return MENU;
  }

  static select(item: MenuKeys) {
    return { ...MENU[item] };
  }

  static describeItem(item: MenuItemValue) { 
    return `${item.name} is a ${item.type.toLowerCase()} that costs $${item.price}`;
  }
}
