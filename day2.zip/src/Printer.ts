import type { MenuItem, Order } from "./models.js";

export class Printer {
  private order;
  constructor(order: Order) {
    this.order = order;
  }

  print(): String {
    const order = this.order;

    const items = `${order.items
      .map((item) => this.printDetails(item))
      .join("\n* ")}`;

    return `
Order ${order.id} (${order.status})

* ${items}

Total: ${this.calculateTotal(order)}
`;
  }

  private printDetails(item: MenuItem) {
    let description: string;
    if (this.isFood(item)) {
      description = `Food: ${item.name}, Calories ${item.calories ?? "N/A"}`;
    } else {
      description = `Drink: ${item.name}, Alcoholic: ${
        item.alcoholic ? "Yes" : "No"
      }`;
    }
    const specialInstruction = this.hasSpecialInstructions(item)
      ? `${item.specialInstructions}`
      : "";

    return `${description} ->  ${item.price}$ ${specialInstruction}`;
  }

  private isFood(item: MenuItem) {
    return item.type === "Food";
  }

  private calculateTotal(order: Order) {
    return order.items.reduce((sum, item) => sum + item.price, 0);
  }

  private hasSpecialInstructions(item: MenuItem) {
    if ("specialInstructions" in item) {
      return item.specialInstructions;
    }
    return null;
  }
}
