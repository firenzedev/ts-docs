type Brand<K, T> = K & { __brand: T };

export type OrderId = Brand<number, "OrderId">;
export type TableId = Brand<number, "TableId">;

const ITEM_TYPES = ["Food", "Drink"] as const;
type ItemType = (typeof ITEM_TYPES)[number];

interface Item {
  name: string;
  type: ItemType;
  price: number;
}

type SpecialItem = Item & { specialInstructions?: string };

export interface FoodItem extends SpecialItem {
  type: "Food";
  calories?: number;
}

interface DrinkItem extends SpecialItem {
  type: "Drink";
  alcoholic?: boolean;
}

export type MenuItem = FoodItem | DrinkItem;

export interface Order {
  id: OrderId;
  items: MenuItem[];
  status: Status;
  tableId: TableId;
}

const STATUS_FLOW = ["Pending", "Preparing", "Ready", "Served"] as const;
export type FlowStatus = (typeof STATUS_FLOW)[number];

export enum Status {
  Pending = "Pending",
  Served = "served",
  Cancelled = "Cancelled",
}
